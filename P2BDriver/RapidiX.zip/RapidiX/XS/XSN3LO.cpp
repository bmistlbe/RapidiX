#include "../includes/CrossSection.h"



void CrossSection::SetN3LO()
{

#include "../XS/N3LO/xs_g_g.txt"
//#include "../XS/N3LO/xs_q_g.txt"
//#include "../XS/N3LO/xs_g_q.txt"
#include "../XS/N3LO/xs_q_qbar.txt"
#include "../XS/N3LO/xs_q_q.txt"
#include "../XS/N3LO/xs_q_Q2.txt"

    return;
    
}
