#include "../includes/CrossSection.h"



void CrossSection::SetNNLO()
{

#include "../XS/NNLO/xs_g_g.txt"
#include "../XS/NNLO/xs_q_g.txt"
#include "../XS/NNLO/xs_g_q.txt"
#include "../XS/NNLO/xs_q_qbar.txt"
#include "../XS/NNLO/xs_q_q.txt"
#include "../XS/NNLO/xs_q_Q2.txt"

    return;
    
}
