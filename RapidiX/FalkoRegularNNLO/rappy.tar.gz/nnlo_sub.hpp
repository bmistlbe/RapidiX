#ifndef __NNLO_SUB_HPP__
#define __NNLO_SUB_HPP__
#include <array>
std::array<double, 6> nnlo_subtraction(double zb);
#endif
